Data Science Dojo <br/>
Copyright (c) 2016 - 2019

---

**Level:** Advanced <br/>
**Recommended Use:** Classification Models<br/>
**Domain:** Healthcare/Social<br/> 

## Autism Screening Adult Data Set 

### Detect Autistic Spectrum Disorder (ASD) cases 


---
![](79.jpg)
---

This *advanced* level data set has 704 rows and 21 columns.
The data set contains Autistic Spectrum Disorder Screening Data for Adult. This dataset can be used for classification and predictive tasks.


This data set is recommended for learning and practicing your skills in **exploratory data analysis**, **data visualization**, and **classification modelling techniques**. 
Feel free to explore the data set with multiple **supervised** and **unsupervised** learning techniques. The Following data dictionary gives more details on this data set:

---

### Data Dictionary 



---

### Acknowledgement

This data set has been sourced from the Machine Learning Repository of University of California, Irvine [Autism Screening Adult Data Set (UC Irvine)](https://archive.ics.uci.edu/ml/datasets/Autism+Screening+Adult). 
The UCI page mentions the following as the original source of the data set:

*Fadi Fayez Thabtah, Department of Digital Technology, Manukau Institute of Technology, Auckland, New Zealand*

