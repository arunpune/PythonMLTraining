# Written Based on Article in Medium
* [Data Visualization using Matplotlib](https://towardsdatascience.com/data-visualization-using-matplotlib-16f1aae5ce70)

